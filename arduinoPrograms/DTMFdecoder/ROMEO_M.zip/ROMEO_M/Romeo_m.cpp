/*Romeo BLE mini���ļ�

  �汾��1.0

  board:Romeo BLE mini

  ��˾���ɶ���Ȥ�Ƽ����޹�˾

  ��վ��http://dfrobot.com.cn
*/





#include "Arduino.h"
#include "Romeo_m.h"

int M3Speed;

void Romeo_mClass::Initialise()
{
	   pinMode(3, OUTPUT);
     pinMode(9, OUTPUT);
     pinMode(5, OUTPUT);
     pinMode(6, OUTPUT);
}
void Romeo_mClass::motorControl(int M1Dir,int M1Speed,int M2Dir,int M2Speed)
{
M3Speed=255-M1Speed;
switch (M1Dir)
{
case 0:
	{ 
		analogWrite(5,M3Speed);
       digitalWrite(3,HIGH);  
	}break;


case 1:
	{ 
		analogWrite(5,M1Speed);
       digitalWrite(3,LOW);  
	}break;
default:break;
}
switch (M2Dir)
{
case 0:
	{ 
		analogWrite(6,M3Speed);
       digitalWrite(9,HIGH);  
	}break;


case 1:
	{ 
		analogWrite(6,M2Speed);
       digitalWrite(9,LOW);  
	}break;
default:break;
}
}

	void Romeo_mClass::motorStop()
	{
		 analogWrite(5,0);
     digitalWrite(3,0);  
     analogWrite(9,0);  
     digitalWrite(6,0);
	}
	
				 
		 

Romeo_mClass Romeo_m;